//products.js
alert("File products.js")
